// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Ian Shores
#pragma once
#include <algorithm>
#include <cmath>
#include <complex>
#include <cstddef>
#include <vector>
#ifndef HEAVYVERB_FFT_STEP
#define HEAVYVERB_FFT_STEP 1
#endif
namespace heavyverb { namespace detail {
// Real transform: pack even/odd samples into a half-size complex FFT.
// Spectrum contract: separate real/imaginary arrays, N/2+1 slots; DC and
// Nyquist are real scalars at slots 0 and N/2. The inverse normalizes by N.
// Plans and scratch are per engine, created off the audio thread.
class RealFFT {
    using Complex = std::complex<float>;
    std::size_t n_, m_;
    std::vector<std::size_t> reverse_;
    std::vector<Complex> roots_, real_roots_, work_;
    void complex_fft(bool inverse) noexcept {
        for (std::size_t i=0;i<m_;++i)
            if (i<reverse_[i]) std::swap(work_[i],work_[reverse_[i]]);
        for (std::size_t len=2;len<=m_;len*=2) {
            const auto half=len/2, step=m_/len;
            for(std::size_t base=0;base<m_;base+=len)
                for(std::size_t j=0;j<half;++j) {
                    const auto w=inverse?std::conj(roots_[j*step]):roots_[j*step];
                    const auto u=work_[base+j], z=work_[base+j+half];
                    const Complex v(z.real()*w.real()-z.imag()*w.imag(),z.real()*w.imag()+z.imag()*w.real());
                    work_[base+j]=u+v; work_[base+j+half]=u-v;
                }
        }
        if(inverse) for(auto& v:work_) v/=float(m_);
    }
public:
    explicit RealFFT(std::size_t n):n_(n),m_(n/2),reverse_(m_),roots_(m_/2),real_roots_(m_),work_(m_) {
        for(std::size_t i=0;i<m_;++i) {
            auto k=i; std::size_t r=0;
            for(auto bit=m_;bit>1;bit>>=1) {r=(r<<1)|(k&1);k>>=1;}
            reverse_[i]=r;
            const double angle=-6.2831853071795864769*double(i)/n_;
            real_roots_[i]=Complex(float(std::cos(angle)),float(std::sin(angle)));
        }
        for(std::size_t i=0;i<m_/2;++i) roots_[i]=real_roots_[2*i];
    }
    std::size_t slot(std::size_t k) const noexcept {return k;}
    std::size_t memory_bytes() const noexcept {
        return sizeof(*this)+reverse_.capacity()*sizeof(std::size_t)+(roots_.capacity()+real_roots_.capacity()+work_.capacity())*sizeof(Complex);
    }
    void forward(const float* time,float* real,float* imag) noexcept {
        for(std::size_t j=0;j<m_;++j) work_[j]=Complex(time[2*j],time[2*j+1]);
        complex_fft(false);
        real[0]=work_[0].real()+work_[0].imag();imag[0]=0;
        real[m_]=work_[0].real()-work_[0].imag();imag[m_]=0;
        for(std::size_t k=1;k<m_;++k) {
            const auto a=work_[k], b=std::conj(work_[m_-k]),w=real_roots_[k];
            const auto d=a-b;
            real[k]=.5f*(a.real()+b.real()+w.real()*d.imag()+w.imag()*d.real());
            imag[k]=.5f*(a.imag()+b.imag()+w.imag()*d.imag()-w.real()*d.real());
        }
    }
    void inverse(const float* real,const float* imag,float* time) noexcept {
        work_[0]=Complex(.5f*(real[0]+real[m_]),.5f*(real[0]-real[m_]));
        for(std::size_t k=1;k<m_;++k) {
            const float xr=real[k],xi=imag[k],yr=real[m_-k],yi=-imag[m_-k];
            const auto w=real_roots_[k];
            const float dr=xr-yr,di=xi-yi;
            work_[k]=Complex(.5f*(xr+yr-w.real()*di+w.imag()*dr),.5f*(xi+yi+w.real()*dr+w.imag()*di));
        }
        complex_fft(true);
        for(std::size_t j=0;j<m_;++j) {time[2*j]=work_[j].real();time[2*j+1]=work_[j].imag();}
    }
};
} }
