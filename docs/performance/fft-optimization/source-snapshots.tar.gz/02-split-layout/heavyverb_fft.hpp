// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Ian Shores
#pragma once
#include <algorithm>
#include <cmath>
#include <complex>
#include <cstddef>
#include <vector>
#ifndef HEAVYVERB_FFT_STEP
#define HEAVYVERB_FFT_STEP 2
#endif
namespace heavyverb { namespace detail {
// Real transform: pack even/odd samples into a half-size complex FFT.
// Spectrum contract: separate real/imaginary arrays, N/2+1 slots; DC and
// Nyquist are real scalars at slots 0 and N/2. The inverse normalizes by N.
// Plans and scratch are per engine, created off the audio thread.
class RealFFT {
    using Complex = std::complex<float>;
    std::size_t n_, m_;
    std::vector<std::size_t> reverse_;
    std::vector<Complex> roots_, real_roots_, work_;
    std::vector<float> r_, i_, twr_, twi_;
    Complex get(std::size_t k) const noexcept {
#if HEAVYVERB_FFT_STEP >= 2
        return Complex(r_[k],i_[k]);
#else
        return work_[k];
#endif
    }
    void set(std::size_t k,Complex x) noexcept {
#if HEAVYVERB_FFT_STEP >= 2
        r_[k]=x.real();i_[k]=x.imag();
#else
        work_[k]=x;
#endif
    }
    void complex_fft(bool inverse) noexcept {
#if HEAVYVERB_FFT_STEP >= 2
        for(std::size_t k=0;k<m_;++k) if(k<reverse_[k]) {std::swap(r_[k],r_[reverse_[k]]);std::swap(i_[k],i_[reverse_[k]]);}
        for(std::size_t len=2;len<=m_;len*=2) {
            const auto half=len/2,step=m_/len;
            for(std::size_t base=0;base<m_;base+=len)
                for(std::size_t j=0;j<half;++j) {
                    const auto a=base+j,b=a+half;
                    const float wr=twr_[j*step],wi=inverse?-twi_[j*step]:twi_[j*step];
                    const float vr=r_[b]*wr-i_[b]*wi,vi=r_[b]*wi+i_[b]*wr,ur=r_[a],ui=i_[a];
                    r_[a]=ur+vr;i_[a]=ui+vi;r_[b]=ur-vr;i_[b]=ui-vi;
                }
        }
        if(inverse)for(std::size_t k=0;k<m_;++k){r_[k]/=float(m_);i_[k]/=float(m_);}
#else
        for (std::size_t i=0;i<m_;++i)
            if (i<reverse_[i]) std::swap(work_[i],work_[reverse_[i]]);
        for (std::size_t len=2;len<=m_;len*=2) {
            const auto half=len/2, step=m_/len;
            for(std::size_t base=0;base<m_;base+=len)
                for(std::size_t j=0;j<half;++j) {
                    const auto w=inverse?std::conj(roots_[j*step]):roots_[j*step];
                    const auto u=work_[base+j], z=work_[base+j+half];
                    const Complex v(z.real()*w.real()-z.imag()*w.imag(),z.real()*w.imag()+z.imag()*w.real());
                    work_[base+j]=u+v; work_[base+j+half]=u-v;
                }
        }
        if(inverse) for(auto& v:work_) v/=float(m_);
#endif
    }
public:
    explicit RealFFT(std::size_t n):n_(n),m_(n/2),reverse_(m_),roots_(m_/2),real_roots_(m_),work_(m_) {
        for(std::size_t i=0;i<m_;++i) {
            auto k=i; std::size_t r=0;
            for(auto bit=m_;bit>1;bit>>=1) {r=(r<<1)|(k&1);k>>=1;}
            reverse_[i]=r;
            const double angle=-6.2831853071795864769*double(i)/n_;
            real_roots_[i]=Complex(float(std::cos(angle)),float(std::sin(angle)));
        }
        for(std::size_t i=0;i<m_/2;++i) roots_[i]=real_roots_[2*i];
#if HEAVYVERB_FFT_STEP >= 2
        r_.resize(m_);i_.resize(m_);twr_.resize(m_/2);twi_.resize(m_/2);
        for(std::size_t k=0;k<m_/2;++k){twr_[k]=roots_[k].real();twi_[k]=roots_[k].imag();}
#endif
    }
    std::size_t slot(std::size_t k) const noexcept {return k;}
    std::size_t memory_bytes() const noexcept {
        return sizeof(*this)+reverse_.capacity()*sizeof(std::size_t)+(roots_.capacity()+real_roots_.capacity()+work_.capacity())*sizeof(Complex)+(r_.capacity()+i_.capacity()+twr_.capacity()+twi_.capacity())*sizeof(float);
    }
    void forward(const float* time,float* real,float* imag) noexcept {
        for(std::size_t j=0;j<m_;++j) set(j,Complex(time[2*j],time[2*j+1]));
        complex_fft(false);
        real[0]=get(0).real()+get(0).imag();imag[0]=0;
        real[m_]=get(0).real()-get(0).imag();imag[m_]=0;
        for(std::size_t k=1;k<m_;++k) {
            const auto a=get(k), b=std::conj(get(m_-k)),w=real_roots_[k];
            const auto d=a-b;
            real[k]=.5f*(a.real()+b.real()+w.real()*d.imag()+w.imag()*d.real());
            imag[k]=.5f*(a.imag()+b.imag()+w.imag()*d.imag()-w.real()*d.real());
        }
    }
    void inverse(const float* real,const float* imag,float* time) noexcept {
        set(0,Complex(.5f*(real[0]+real[m_]),.5f*(real[0]-real[m_])));
        for(std::size_t k=1;k<m_;++k) {
            const float xr=real[k],xi=imag[k],yr=real[m_-k],yi=-imag[m_-k];
            const auto w=real_roots_[k];
            const float dr=xr-yr,di=xi-yi;
            set(k,Complex(.5f*(xr+yr-w.real()*di+w.imag()*dr),.5f*(xi+yi+w.real()*dr+w.imag()*di)));
        }
        complex_fft(true);
        for(std::size_t j=0;j<m_;++j) {time[2*j]=get(j).real();time[2*j+1]=get(j).imag();}
    }
};
} }
